# Trained Model Weights

This directory will contain trained Pyro/PyTorch model weights after running:

```bash
python scripts/02_train_bnn.py
```

## Expected files (after training)

```
models/
├── bnn_v2_seed42.pt
├── bnn_v2_seed123.pt
├── bnn_v2_seed456.pt
├── bnn_v2_seed789.pt
└── bnn_v2_seed1024.pt
```

Each file contains the Pyro parameter store (variational posterior parameters) for one BNN.

## Why aren't they in the repo?

Pyro parameter stores can be large (~5-15 MB each, ~50 MB total for the ensemble). To keep the repository lightweight, we ship only the **predictions** (`results/all_predictions_v2_6tasks.csv`), which are the practical product of training. Reproducing the weights takes ~20 minutes on a Tesla T4 GPU.

## Loading saved models

```python
import pyro
pyro.get_param_store().load("models/bnn_v2_seed42.pt")
```

After loading, see `scripts/02_train_bnn.py` for the model and guide construction.
