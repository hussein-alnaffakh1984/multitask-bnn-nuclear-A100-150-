# Changelog

All notable changes to this project will be documented here.

## [v2.0] — 2026-05-10

### Added — 6-output multi-task framework
- **3 new prediction targets**:
  - `S(2n)` — two-neutron separation energy (test R² = 0.985)
  - `E(4⁺)` — first 4⁺ excitation energy (test R² = 0.689)
  - `R(4/2)` — E(4⁺)/E(2⁺) ratio, shape indicator (test R² = 0.630)
- **Ablation study** comparing single-task BNN, multi-task BNN, and multi-task ensemble
- **Baseline comparison** against random forest, XGBoost, and deterministic neural network
- **CRPS metric** added alongside ECE and coverage for calibration assessment
- **NUDAT3 scraper** (170 nuclei) recovering E(4⁺) and R(4/2) values
- **Webapp v2** with 8 sections including Validation, Ablation, and 6-output predictions

### Improved
- E(2⁺) prediction R² improved from 0.384 to 0.496 (+29%) thanks to multi-task learning
- ¹³²Sn doubly-magic outlier now within 0.7σ when predictive uncertainty is honored
  (previously displayed as 34σ deviation when ignoring uncertainty)
- Webapp rebuilt from 4 sections to 8 sections covering all 6 outputs
- Paper rewritten as v4 addressing 10 Q1-reviewer concerns:
  - Direct numerical comparison with prior BNN studies (Table 8)
  - Ablation study with explicit numbers (Table 5)
  - Baseline comparison table (Table 6)
  - Physics interpretation of multi-task gains (Section 5.1)
  - 132Sn limitation handled with shell-closure singularity discussion
  - Conclusion strengthened with r-process / RIB facility implications
  - Toned-down language ("first" → "to the best of our knowledge")
  - Calibration analysis enhanced with CRPS and NLL

### Architecture
- 6 Bayesian heads (was 3) with cross-task masking
- Same shared trunk: 11 features → 64 → 32 → ReLU → dropout 0.1
- Same ensemble: 5 seeds × 100 posterior samples = 500 samples per nucleus
- Same hyperparameters: lr=0.01, prior std=2.0, 2000 epochs, Adam optimizer

### Files added
- `data/master_v2_6targets.csv` — extended training set (651 × 6 targets)
- `results/all_predictions_v2_6tasks.csv` — predictions for all 651 nuclei
- `results/test_results_v2_6tasks.csv` — held-out test set
- `results/validation_v2_6tasks.csv` — 10 reference nuclei
- `results/sn_chain_v2_6tasks.csv` — Sn chain (12 isotopes)
- `results/metrics_v2_6tasks.csv` — performance summary
- `paper/Multi-Task-BNN-Nuclear-A100-150-v4.docx` — final manuscript
- `webapp/` — completely rebuilt 8-section interactive web app
- `scripts/01_build_dataset.py`, `02_train_bnn.py`, `03_metrics.py`, `stage7b_all_in_one.py`

---

## [v1.0] — 2026-05-09

### Initial release — 3-output framework
- 3 prediction targets: mass excess, E(2⁺), B(E2)
- Multi-task BNN with 3 Bayesian heads
- 5-seed ensemble with 100 posterior samples per seed
- Test R²: 0.992 (mass), 0.384 (E(2⁺)), 0.945 (B(E2))
- Webapp with 4 sections: Overview, Predictions, Nuclear Chart, Sn Chain
- Paper draft (v1, v2, v3 iterations)
- 6 publication-quality figures
- 25 verified references in Vancouver style
