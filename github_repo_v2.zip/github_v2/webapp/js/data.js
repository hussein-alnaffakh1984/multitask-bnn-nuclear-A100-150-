// ================================================================
// Multi-Task BNN Webapp — Data (v2: 6 outputs)
// 651 nuclei × 6 observables = mass, S2n, E(2+), E(4+), R(4/2), B(E2)
// Each: experimental (E), predicted (P), uncertainty (U)
// ================================================================

// Targets metadata
const TARGETS = [
  { key: 'm', expCol: 'mE', predCol: 'mP', uncCol: 'mU',
    name: 'Mass excess', unit: 'keV', shortName: 'Mass',
    rmse: 1296, r2: 0.993, ece: 0.212, cov95: 1.00,
    description: 'Atomic mass excess (M − A·u)·c² from AME2020' },
  { key: 's', expCol: 'sE', predCol: 'sP', uncCol: 'sU',
    name: 'S(2n)', unit: 'keV', shortName: 'S(2n)',
    rmse: 617, r2: 0.985, ece: 0.202, cov95: 0.989,
    description: 'Two-neutron separation energy from AME2020' },
  { key: 'e', expCol: 'eE', predCol: 'eP', uncCol: 'eU',
    name: 'E(2⁺)', unit: 'keV', shortName: 'E(2+)',
    rmse: 233, r2: 0.496, ece: 0.111, cov95: 1.00,
    description: 'First 2⁺ excitation energy from Pritychenko 2016' },
  { key: 'f', expCol: 'fE', predCol: 'fP', uncCol: 'fU',
    name: 'E(4⁺)', unit: 'keV', shortName: 'E(4+)',
    rmse: 354, r2: 0.689, ece: 0.155, cov95: 0.826,
    description: 'First 4⁺ excitation energy from NUDAT3' },
  { key: 'r', expCol: 'rE', predCol: 'rP', uncCol: 'rU',
    name: 'R(4/2)', unit: '', shortName: 'R(4/2)',
    rmse: 0.476, r2: 0.630, ece: 0.242, cov95: 0.652,
    description: 'E(4⁺)/E(2⁺) ratio — shape indicator (≈2 vibrational, ≈3.33 rotational)' },
  { key: 'b', expCol: 'bE', predCol: 'bP', uncCol: 'bU',
    name: 'B(E2)↑', unit: 'e²b²', shortName: 'B(E2)',
    rmse: 0.267, r2: 0.920, ece: 0.062, cov95: 1.00,
    description: 'Reduced E2 transition probability 0⁺ → 2⁺ from Pritychenko 2016' },
];

// Element symbols by Z
const ELEMENTS = {
  40:'Zr',41:'Nb',42:'Mo',43:'Tc',44:'Ru',45:'Rh',46:'Pd',47:'Ag',48:'Cd',49:'In',
  50:'Sn',51:'Sb',52:'Te',53:'I', 54:'Xe',55:'Cs',56:'Ba',57:'La',58:'Ce',59:'Pr',60:'Nd'
};

// 10 reference nuclei used in validation
const VALIDATION_NUCLEI = [
  { Z: 42, N: 58, A: 100, EL: 'Mo', note: '' },
  { Z: 46, N: 62, A: 108, EL: 'Pd', note: '' },
  { Z: 48, N: 68, A: 116, EL: 'Cd', note: '' },
  { Z: 50, N: 66, A: 116, EL: 'Sn', note: 'Sn anomaly' },
  { Z: 50, N: 70, A: 120, EL: 'Sn', note: '' },
  { Z: 50, N: 82, A: 132, EL: 'Sn', note: 'Doubly magic' },
  { Z: 52, N: 78, A: 130, EL: 'Te', note: '' },
  { Z: 54, N: 82, A: 136, EL: 'Xe', note: '' },
  { Z: 58, N: 82, A: 140, EL: 'Ce', note: '' },
  { Z: 60, N: 80, A: 140, EL: 'Nd', note: '' },
];

// Ablation study data (from paper Table 5)
const ABLATION = [
  { task: 'Mass excess (keV)',  single: 'RMSE 1340 / R² 0.992', multi1: 'RMSE 1350 / R² 0.992', multiE: 'RMSE 1296 / R² 0.993' },
  { task: 'S(2n) (keV)',        single: 'RMSE 685 / R² 0.981',  multi1: 'RMSE 645 / R² 0.984',  multiE: 'RMSE 617 / R² 0.985' },
  { task: 'E(2⁺) (keV)',        single: 'RMSE 670 / R² 0.384',  multi1: 'RMSE 257 / R² 0.439',  multiE: 'RMSE 233 / R² 0.496', highlight: true },
  { task: 'E(4⁺) (keV)',        single: 'RMSE 401 / R² 0.621',  multi1: 'RMSE 380 / R² 0.658',  multiE: 'RMSE 354 / R² 0.689' },
  { task: 'R(4/2)',             single: 'RMSE 0.531 / R² 0.546', multi1: 'RMSE 0.502 / R² 0.591', multiE: 'RMSE 0.476 / R² 0.630' },
  { task: 'B(E2) (e²b²)',       single: 'RMSE 0.297 / R² 0.908', multi1: 'RMSE 0.281 / R² 0.913', multiE: 'RMSE 0.267 / R² 0.920' },
];

// Baseline comparison (from paper Table 6)
const BASELINES = [
  { task: 'Mass excess', rf: '1820', xgb: '1310', dnn: '1380', bnn: '1296' },
  { task: 'S(2n)',       rf: '780',  xgb: '608',  dnn: '651',  bnn: '617' },
  { task: 'E(2⁺)',       rf: '298',  xgb: '275',  dnn: '251',  bnn: '233' },
  { task: 'E(4⁺)',       rf: '412',  xgb: '376',  dnn: '361',  bnn: '354' },
  { task: 'R(4/2)',      rf: '0.561',xgb: '0.494',dnn: '0.483',bnn: '0.476' },
  { task: 'B(E2)',       rf: '0.341',xgb: '0.289',dnn: '0.275',bnn: '0.267' },
];

// Will be filled by fetching nuclei_data.json
let NUCLEI_DATA = [];

// Load data asynchronously
async function loadNucleiData() {
  if (NUCLEI_DATA.length > 0) return NUCLEI_DATA;
  try {
    const response = await fetch('nuclei_data.json');
    NUCLEI_DATA = await response.json();
    return NUCLEI_DATA;
  } catch (e) {
    console.error('Failed to load nuclei_data.json:', e);
    return [];
  }
}

// Helper: lookup nucleus by (Z, N)
function findNucleus(Z, N) {
  return NUCLEI_DATA.find(n => n.Z === parseInt(Z) && n.N === parseInt(N));
}

// Helper: format prediction with uncertainty
function fmtPred(value, uncertainty, decimals = 0) {
  if (value === null || value === undefined) return '—';
  const v = decimals === 0 ? Math.round(value) : value.toFixed(decimals);
  const u = decimals === 0 ? Math.round(uncertainty) : uncertainty.toFixed(decimals);
  return `${v} ± ${u}`;
}

function fmtExp(value, decimals = 0) {
  if (value === null || value === undefined) return 'not measured';
  return decimals === 0 ? Math.round(value).toString() : value.toFixed(decimals);
}

// Compute deviation in sigma
function computeDeviation(exp, pred, unc) {
  if (exp === null || exp === undefined || unc === 0) return null;
  return Math.abs(exp - pred) / unc;
}
