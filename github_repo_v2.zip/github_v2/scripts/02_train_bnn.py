# ============================================================
# CELL 2 (Stage 7B): Train 6-Task BNN Ensemble
# ============================================================
# الهدف: تدريب 5 BNNs بـ 6 رؤوس على الـ master_v2_6targets.csv
# Architecture: Shared trunk (64→32) + 6 Bayesian heads
# ============================================================

import torch
import torch.nn as nn
import torch.nn.functional as F
import pyro
import pyro.distributions as dist
from pyro.nn import PyroModule, PyroSample
from pyro.infer import SVI, Trace_ELBO
from pyro.infer.autoguide import AutoNormal
from pyro.optim import Adam
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import time

# -----------------------------------------------------------
# Config
# -----------------------------------------------------------
output_dir = Path("/kaggle/working/data")
bnn_dir    = Path("/kaggle/working/bnn_data_v2")
models_dir = bnn_dir / "models_v2"
models_dir.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")

# Hyperparameters (same as Stage 6 winning config)
HPARAMS = {
    'trunk_hidden':    [64, 32],
    'head_hidden':     16,
    'prior_std':       2.0,
    'learning_rate':   0.01,
    'epochs':          2000,
    'dropout':         0.1,
    'n_seeds':         5,
    'n_posterior':     100,  # samples per seed for prediction
}

SEEDS = [42, 123, 456, 789, 1024]

# Targets (6 tasks)
TARGET_NAMES = ['T1_mass_excess', 'T2_S_2n', 'T3_E_2plus',
                'T4_E_4plus',     'T5_R_42', 'T6_BE2_up']
TARGET_LABELS = ['Mass excess', 'S(2n)', 'E(2⁺)', 'E(4⁺)', 'R(4/2)', 'B(E2)↑']

# -----------------------------------------------------------
# Load data
# -----------------------------------------------------------
print("\n" + "="*70)
print("Stage 7B: 6-Task BNN Training")
print("="*70)

df = pd.read_csv(bnn_dir / "master_v2_6targets.csv")
print(f"\n📂 Loaded master_v2_6targets.csv: {df.shape}")

feature_cols = [c for c in df.columns if c.startswith('F0') or c.startswith('F1')]
print(f"   Features: {len(feature_cols)}")
print(f"   Targets:  {len(TARGET_NAMES)}")

X_full = df[feature_cols].values.astype(np.float32)
print(f"   X shape: {X_full.shape}")

# -----------------------------------------------------------
# Multi-Task BNN Model with 6 heads
# -----------------------------------------------------------
class MultiTaskBNN_6Tasks(PyroModule):
    """
    Shared trunk: 11 → 64 → 32 (deterministic with dropout)
    6 Bayesian heads: 32 → 16 → 1 (each)
    """
    def __init__(self, n_features=11, n_tasks=6,
                 trunk_h=[64, 32], head_h=16,
                 prior_std=2.0, dropout=0.1):
        super().__init__()
        self.n_tasks = n_tasks
        self.prior_std = prior_std
        self.dropout = dropout

        # Deterministic shared trunk
        self.trunk = nn.Sequential(
            nn.Linear(n_features, trunk_h[0]),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(trunk_h[0], trunk_h[1]),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # 6 Bayesian heads
        self.heads = PyroModule[nn.ModuleList](
            [self._make_bayesian_head(trunk_h[1], head_h, prior_std)
             for _ in range(n_tasks)]
        )

    def _make_bayesian_head(self, in_dim, hidden, prior_std):
        head = PyroModule[nn.Sequential](
            PyroModule[nn.Linear](in_dim, hidden),
            nn.ReLU(),
            PyroModule[nn.Linear](hidden, 1),
        )
        # Set Gaussian priors on all Bayesian weights
        for layer in head:
            if isinstance(layer, PyroModule[nn.Linear]):
                layer.weight = PyroSample(
                    dist.Normal(0., prior_std).expand(layer.weight.shape).to_event(2)
                )
                layer.bias = PyroSample(
                    dist.Normal(0., prior_std).expand(layer.bias.shape).to_event(1)
                )
        return head

    def forward(self, x, y_list=None, mask_list=None):
        """
        x:        (batch, n_features)
        y_list:   list of 6 tensors (each ≤ batch, with NaN where missing)
        mask_list:list of 6 boolean tensors marking valid samples per task
        """
        h = self.trunk(x)
        preds = []

        for k in range(self.n_tasks):
            pred_k = self.heads[k](h).squeeze(-1)  # (batch,)
            preds.append(pred_k)

            if y_list is not None and mask_list is not None:
                mask_k = mask_list[k]
                if mask_k.sum() > 0:
                    sigma_k = pyro.sample(
                        f"sigma_{k}",
                        dist.HalfNormal(1.0)
                    )
                    with pyro.plate(f"data_{k}", mask_k.sum()):
                        pyro.sample(
                            f"obs_{k}",
                            dist.Normal(pred_k[mask_k], sigma_k),
                            obs=y_list[k][mask_k]
                        )
        return preds


# -----------------------------------------------------------
# Per-task scalers (normalize targets in their own units)
# -----------------------------------------------------------
def fit_per_task_scaler(y_array):
    """Fit a StandardScaler per task on non-NaN values"""
    scalers = []
    for k in range(y_array.shape[1]):
        s = StandardScaler()
        valid = ~np.isnan(y_array[:, k])
        if valid.sum() > 0:
            s.fit(y_array[valid, k:k+1])
        scalers.append(s)
    return scalers

def transform_per_task(y_array, scalers):
    """Transform each task column with its scaler (NaNs preserved)"""
    out = np.full_like(y_array, np.nan, dtype=np.float32)
    for k, s in enumerate(scalers):
        valid = ~np.isnan(y_array[:, k])
        if valid.sum() > 0:
            out[valid, k] = s.transform(y_array[valid, k:k+1]).ravel()
    return out

def inverse_per_task(y_scaled, scalers):
    out = np.full_like(y_scaled, np.nan, dtype=np.float32)
    for k, s in enumerate(scalers):
        valid = ~np.isnan(y_scaled[:, k])
        if valid.sum() > 0:
            out[valid, k] = s.inverse_transform(y_scaled[valid, k:k+1]).ravel()
    return out


# -----------------------------------------------------------
# Train one BNN with given seed
# -----------------------------------------------------------
def train_one_bnn(X_tr, Y_tr, seed):
    """
    X_tr: (N, 11) features standardized
    Y_tr: (N, 6) targets standardized per-task, with NaNs for missing
    """
    pyro.set_rng_seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    pyro.clear_param_store()

    model = MultiTaskBNN_6Tasks(
        n_features=X_tr.shape[1], n_tasks=6,
        trunk_h=HPARAMS['trunk_hidden'],
        head_h=HPARAMS['head_hidden'],
        prior_std=HPARAMS['prior_std'],
        dropout=HPARAMS['dropout'],
    ).to(DEVICE)

    guide = AutoNormal(model)
    optimizer = Adam({"lr": HPARAMS['learning_rate']})
    svi = SVI(model, guide, optimizer, loss=Trace_ELBO())

    # Prepare per-task masks and y tensors
    X_t = torch.tensor(X_tr, dtype=torch.float32).to(DEVICE)
    y_list = []
    mask_list = []
    for k in range(6):
        y_col = Y_tr[:, k]
        mask = torch.tensor(~np.isnan(y_col), dtype=torch.bool).to(DEVICE)
        y_t = torch.tensor(np.nan_to_num(y_col), dtype=torch.float32).to(DEVICE)
        y_list.append(y_t)
        mask_list.append(mask)

    losses = []
    for epoch in range(HPARAMS['epochs']):
        loss = svi.step(X_t, y_list, mask_list)
        losses.append(loss)
        if (epoch+1) % 200 == 0:
            print(f"      [seed {seed}] Epoch {epoch+1:>4d}/{HPARAMS['epochs']}  ELBO loss = {loss:.1f}")

    return model, guide, losses


# -----------------------------------------------------------
# Posterior prediction
# -----------------------------------------------------------
def predict_posterior(model, guide, X, n_samples=100):
    """Returns (n_samples, N, 6) predictions in scaled space"""
    X_t = torch.tensor(X, dtype=torch.float32).to(DEVICE)
    samples = []
    for _ in range(n_samples):
        guide_trace = pyro.poutine.trace(guide).get_trace(X_t)
        replayed = pyro.poutine.replay(model, trace=guide_trace)
        with torch.no_grad():
            preds = replayed(X_t)
        sample = torch.stack(preds, dim=-1).cpu().numpy()  # (N, 6)
        samples.append(sample)
    return np.array(samples)  # (n_samples, N, 6)


# -----------------------------------------------------------
# 70/15/15 split (deterministic — same seed for all BNNs)
# -----------------------------------------------------------
print("\n📐 Splitting data 70/15/15...")
N = len(df)
indices = np.arange(N)
np.random.seed(42)
np.random.shuffle(indices)
n_tr = int(0.70 * N)
n_va = int(0.15 * N)
idx_tr = indices[:n_tr]
idx_va = indices[n_tr:n_tr+n_va]
idx_te = indices[n_tr+n_va:]
print(f"   Train: {len(idx_tr)},  Val: {len(idx_va)},  Test: {len(idx_te)}")

X_tr = X_full[idx_tr]
X_va = X_full[idx_va]
X_te = X_full[idx_te]

Y_full = df[TARGET_NAMES].values.astype(np.float32)
Y_tr = Y_full[idx_tr]
Y_va = Y_full[idx_va]
Y_te = Y_full[idx_te]

# Standardize features
x_scaler = StandardScaler().fit(X_tr)
X_tr_s = x_scaler.transform(X_tr).astype(np.float32)
X_va_s = x_scaler.transform(X_va).astype(np.float32)
X_te_s = x_scaler.transform(X_te).astype(np.float32)

# Standardize targets per-task
y_scalers = fit_per_task_scaler(Y_tr)
Y_tr_s   = transform_per_task(Y_tr, y_scalers)
Y_va_s   = transform_per_task(Y_va, y_scalers)
Y_te_s   = transform_per_task(Y_te, y_scalers)

# -----------------------------------------------------------
# Train ensemble of 5 BNNs
# -----------------------------------------------------------
print(f"\n🧠 Training ensemble of {HPARAMS['n_seeds']} BNNs...")
print(f"   Each: {HPARAMS['epochs']} epochs, ~100s on T4")

ensemble_preds_te_scaled = []   # list of (n_samples, N_test, 6)
ensemble_preds_full_scaled = [] # list of (n_samples, 651, 6) for ALL nuclei

start = time.time()
for seed_idx, seed in enumerate(SEEDS):
    print(f"\n   [{seed_idx+1}/{HPARAMS['n_seeds']}] Training seed={seed}...")
    t0 = time.time()
    model, guide, losses = train_one_bnn(X_tr_s, Y_tr_s, seed)
    elapsed = time.time() - t0
    print(f"      ✅ Trained in {elapsed:.1f}s")

    # Save model state
    pyro.get_param_store().save(str(models_dir / f"bnn_v2_seed{seed}.pt"))

    # Predictions on test set
    preds_te = predict_posterior(model, guide, X_te_s, HPARAMS['n_posterior'])
    ensemble_preds_te_scaled.append(preds_te)

    # Predictions on FULL dataset (for download/use)
    X_full_s = x_scaler.transform(X_full).astype(np.float32)
    preds_full = predict_posterior(model, guide, X_full_s, HPARAMS['n_posterior'])
    ensemble_preds_full_scaled.append(preds_full)

total_time = time.time() - start
print(f"\n   ⏱️ Total ensemble training time: {total_time/60:.1f} minutes")

# -----------------------------------------------------------
# Combine ensemble predictions
# -----------------------------------------------------------
print(f"\n🎯 Combining ensemble predictions...")

# Test set
all_preds_te = np.concatenate(ensemble_preds_te_scaled, axis=0)  # (5*100, N_test, 6)
mean_te_scaled = all_preds_te.mean(axis=0)
std_te_scaled  = all_preds_te.std(axis=0)
mean_te = inverse_per_task(mean_te_scaled, y_scalers)
# Inverse for std: multiply by per-task std (since standardization is linear)
std_te = std_te_scaled.copy()
for k, s in enumerate(y_scalers):
    if hasattr(s, 'scale_'):
        std_te[:, k] = std_te_scaled[:, k] * s.scale_[0]

# Full dataset
all_preds_full = np.concatenate(ensemble_preds_full_scaled, axis=0)
mean_full_scaled = all_preds_full.mean(axis=0)
std_full_scaled  = all_preds_full.std(axis=0)
mean_full = inverse_per_task(mean_full_scaled, y_scalers)
std_full = std_full_scaled.copy()
for k, s in enumerate(y_scalers):
    if hasattr(s, 'scale_'):
        std_full[:, k] = std_full_scaled[:, k] * s.scale_[0]

# -----------------------------------------------------------
# Save predictions
# -----------------------------------------------------------
print(f"\n💾 Saving predictions...")

# Test set with metrics
test_results = pd.DataFrame({
    'Z': df.iloc[idx_te]['Z'].values,
    'N': df.iloc[idx_te]['N'].values,
    'A': df.iloc[idx_te]['A'].values,
    'EL': df.iloc[idx_te]['EL'].values,
})
for k, t in enumerate(TARGET_NAMES):
    test_results[f'{t}_exp']  = Y_te[:, k]
    test_results[f'{t}_pred'] = mean_te[:, k]
    test_results[f'{t}_unc']  = std_te[:, k]
test_results.to_csv(bnn_dir / "test_results_v2_6tasks.csv", index=False)
print(f"   ✅ test_results_v2_6tasks.csv  ({(bnn_dir / 'test_results_v2_6tasks.csv').stat().st_size/1024:.1f} KB)")

# Full predictions for all 651 nuclei
all_predictions = df[['Z', 'N', 'A', 'EL']].copy()
for k, t in enumerate(TARGET_NAMES):
    all_predictions[f'{t}_exp']  = Y_full[:, k]
    all_predictions[f'{t}_pred'] = mean_full[:, k]
    all_predictions[f'{t}_unc']  = std_full[:, k]
all_predictions.to_csv(bnn_dir / "all_predictions_v2_6tasks.csv", index=False)
print(f"   ✅ all_predictions_v2_6tasks.csv  ({(bnn_dir / 'all_predictions_v2_6tasks.csv').stat().st_size/1024:.1f} KB)")

# Save split indices for reproducibility
split_info = pd.DataFrame({
    'index': np.concatenate([idx_tr, idx_va, idx_te]),
    'split': ['train']*len(idx_tr) + ['val']*len(idx_va) + ['test']*len(idx_te)
})
split_info.to_csv(bnn_dir / "split_v2.csv", index=False)
print(f"   ✅ split_v2.csv")

print(f"\n✅ Cell 2 complete. Move to Cell 3 (evaluation & metrics).")
