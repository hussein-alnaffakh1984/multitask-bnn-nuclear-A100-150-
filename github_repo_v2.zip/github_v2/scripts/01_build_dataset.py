# ============================================================
# CELL 1 (Stage 7B): Build EXTENDED master dataset with 6 targets
# ============================================================
# الهدف: دمج E(4+) و R_42 من nudat_data_A100to150.csv مع master
# ثم إنشاء dataset جاهز للتدريب على 6 مخرجات
# ============================================================

import pandas as pd
import numpy as np
from pathlib import Path

output_dir = Path("/kaggle/working/data")
bnn_dir    = Path("/kaggle/working/bnn_data_v2")
bnn_dir.mkdir(parents=True, exist_ok=True)

print("="*70)
print("Stage 7B: Building 6-target master dataset")
print("="*70)

# -----------------------------------------------------------
# Load existing data
# -----------------------------------------------------------
print("\n📂 Loading existing data files...")

# Master with mass + Pritychenko B(E2) + E(2+)
master = pd.read_csv(output_dir / "master_dataset_with_BE2.csv")
print(f"   master_dataset_with_BE2.csv: {len(master)} rows × {len(master.columns)} cols")

# NUDAT-derived data (E_4plus, R_42, etc.)
nudat = pd.read_csv(output_dir / "nudat_data_A100to150.csv")
print(f"   nudat_data_A100to150.csv:    {len(nudat)} rows × {len(nudat.columns)} cols")

# -----------------------------------------------------------
# Merge E(4+) and R_42 from nudat into master
# -----------------------------------------------------------
print("\n🔗 Merging E(4+) and R_42 from NUDAT into master...")

# nudat columns to bring in
nudat_cols_to_merge = ['Z', 'A', 'E_2plus_keV', 'E_4plus_keV', 'R_42']
nudat_subset = nudat[nudat_cols_to_merge].copy()
nudat_subset = nudat_subset.rename(columns={
    'E_2plus_keV': 'E_2plus_keV_NUDAT',  # rename to avoid clash with Pritychenko
    'E_4plus_keV': 'E_4plus_keV_NUDAT',
    'R_42': 'R_42_NUDAT',
})

# Merge on (Z, A)
extended = master.merge(nudat_subset, on=['Z', 'A'], how='left')
print(f"   Extended dataset: {len(extended)} rows × {len(extended.columns)} cols")

# -----------------------------------------------------------
# Build the 6 final target columns (with clear naming)
# -----------------------------------------------------------
print("\n🎯 Building 6 target columns...")

extended['T1_mass_excess']    = extended['mass_excess_keV_value']        # 651
extended['T2_S_2n']           = extended['S_2n_value']                   # 630
extended['T3_E_2plus']        = extended['E_2plus_keV_Priti']            # 147
extended['T4_E_4plus']        = extended['E_4plus_keV_NUDAT']            # ~141
extended['T5_R_42']           = extended['R_42_NUDAT']                   # ~141
extended['T6_BE2_up']         = extended['BE2_up_e2b2_Priti']            # 134

# Coverage report
print(f"\n📊 Final 6-target coverage:")
print(f"   {'Target':<25s} {'Source':<25s} {'N':>6s} {'%':>7s}")
print("-"*70)
sources = {
    'T1_mass_excess':  'AME2020 (mass_excess)',
    'T2_S_2n':         'AME2020 (S_2n)',
    'T3_E_2plus':      'Pritychenko 2016',
    'T4_E_4plus':      'NUDAT3 (4⁺ levels)',
    'T5_R_42':         'NUDAT3 (computed)',
    'T6_BE2_up':       'Pritychenko 2016',
}
for col, src in sources.items():
    n = extended[col].notna().sum()
    pct = 100 * n / len(extended)
    print(f"   {col:<25s} {src:<25s} {n:>6d} {pct:>6.1f}%")

# -----------------------------------------------------------
# Build 11 input features (same as Stage 6)
# -----------------------------------------------------------
print(f"\n🔧 Building 11 input features...")

def magic_distance_proton(Z):
    return min(abs(Z - 50), abs(Z - 82))

def magic_distance_neutron(N):
    return min(abs(N - 50), abs(N - 82))

def valence_nucleons(Z, N):
    """Number of nucleons outside nearest closed shell"""
    p_distances = [abs(Z - m) for m in [28, 50, 82, 126]]
    n_distances = [abs(N - m) for m in [28, 50, 82, 126]]
    return min(p_distances) + min(n_distances)

extended['F01_Z']         = extended['Z']
extended['F02_N']         = extended['N']
extended['F03_A']         = extended['A']
extended['F04_dZ50']      = (extended['Z'] - 50).abs()
extended['F05_dZ82']      = (extended['Z'] - 82).abs()
extended['F06_dN50']      = (extended['N'] - 50).abs()
extended['F07_dN82']      = (extended['N'] - 82).abs()
extended['F08_Zmod2']     = extended['Z'] % 2
extended['F09_Nmod2']     = extended['N'] % 2
extended['F10_valence']   = extended.apply(lambda r: valence_nucleons(r['Z'], r['N']), axis=1)
extended['F11_eveneven']  = ((extended['Z'] % 2 == 0) & (extended['N'] % 2 == 0)).astype(int)

feature_cols = [f'F{i:02d}_' for i in range(1, 12)]
feature_cols = [c for c in extended.columns if c.startswith('F0') or c.startswith('F1')]
print(f"   Built {len(feature_cols)} features")

# -----------------------------------------------------------
# Save extended master
# -----------------------------------------------------------
target_cols  = [f'T{i}_' for i in range(1, 7)]
target_cols  = [c for c in extended.columns if c.startswith('T1_') or c.startswith('T2_')
                or c.startswith('T3_') or c.startswith('T4_') or c.startswith('T5_')
                or c.startswith('T6_')]

# Final columns: identifiers + features + targets
keep_cols = ['Z', 'N', 'A', 'EL'] + feature_cols + target_cols
extended_final = extended[keep_cols].copy()

extended_final.to_csv(bnn_dir / "master_v2_6targets.csv", index=False)
print(f"\n💾 Saved: {bnn_dir / 'master_v2_6targets.csv'}")
print(f"   Shape: {extended_final.shape}")
print(f"   Size:  {(bnn_dir / 'master_v2_6targets.csv').stat().st_size/1024:.1f} KB")

# Show first 5 rows
print(f"\n📋 First 5 rows preview:")
print(extended_final[['Z', 'N', 'A', 'EL'] + target_cols].head().to_string(index=False))

print(f"\n✅ Cell 1 complete. Move to Cell 2 (BNN training).")
