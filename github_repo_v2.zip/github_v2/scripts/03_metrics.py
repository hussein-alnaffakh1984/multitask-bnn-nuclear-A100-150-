# ============================================================
# CELL 3 (Stage 7B): Metrics, Calibration, and Final Deliverables
# ============================================================
# الهدف: حساب RMSE, R², ECE, coverage لكل المخرجات الـ 6
# ثم packaging كل الملفات لإرسالها لـ Claude
# ============================================================

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import r2_score, mean_squared_error
import zipfile

bnn_dir = Path("/kaggle/working/bnn_data_v2")

print("="*70)
print("Stage 7B: Metrics + Calibration + Packaging")
print("="*70)

# -----------------------------------------------------------
# Load predictions
# -----------------------------------------------------------
test_results = pd.read_csv(bnn_dir / "test_results_v2_6tasks.csv")
all_preds    = pd.read_csv(bnn_dir / "all_predictions_v2_6tasks.csv")

TARGET_NAMES = ['T1_mass_excess', 'T2_S_2n', 'T3_E_2plus',
                'T4_E_4plus',     'T5_R_42', 'T6_BE2_up']
TARGET_LABELS = {
    'T1_mass_excess': 'Mass excess (keV)',
    'T2_S_2n':        'S(2n) (keV)',
    'T3_E_2plus':     'E(2⁺) (keV)',
    'T4_E_4plus':     'E(4⁺) (keV)',
    'T5_R_42':        'R(4/2) ratio',
    'T6_BE2_up':      'B(E2)↑ (e²b²)',
}

# -----------------------------------------------------------
# Test-set performance metrics
# -----------------------------------------------------------
print("\n📊 Test-set performance metrics")
print("-"*70)
print(f"{'Task':<25s} {'N':>4s} {'RMSE':>12s} {'R²':>7s} {'ECE':>7s} {'Cov68':>7s} {'Cov95':>7s}")
print("-"*70)

metrics_summary = []
for t in TARGET_NAMES:
    exp = test_results[f'{t}_exp'].values
    pred = test_results[f'{t}_pred'].values
    unc  = test_results[f'{t}_unc'].values
    valid = ~np.isnan(exp)

    n = valid.sum()
    if n < 2:
        metrics_summary.append({
            'task': t, 'label': TARGET_LABELS[t], 'n_test': n,
            'rmse': np.nan, 'r2': np.nan, 'ece': np.nan,
            'cov68': np.nan, 'cov95': np.nan
        })
        continue

    e = exp[valid]; p = pred[valid]; u = unc[valid]
    rmse = np.sqrt(np.mean((e - p)**2))
    r2 = r2_score(e, p)

    # Coverage at multiple alpha levels for ECE
    alphas = np.linspace(0.05, 0.99, 20)
    coverages = []
    from scipy.stats import norm
    for a in alphas:
        z = norm.ppf((1 + a) / 2)  # two-sided
        cov = np.mean(np.abs(e - p) <= z * u)
        coverages.append(cov)
    coverages = np.array(coverages)
    ece = np.mean(np.abs(coverages - alphas))

    # Specific 68% and 95% coverage
    cov68 = np.mean(np.abs(e - p) <= 1.0 * u)
    cov95 = np.mean(np.abs(e - p) <= 1.96 * u)

    metrics_summary.append({
        'task': t, 'label': TARGET_LABELS[t], 'n_test': int(n),
        'rmse': float(rmse), 'r2': float(r2), 'ece': float(ece),
        'cov68': float(cov68), 'cov95': float(cov95)
    })

    print(f"{TARGET_LABELS[t]:<25s} {n:>4d} {rmse:>12.4g} {r2:>7.3f} "
          f"{ece:>7.3f} {cov68*100:>6.1f}% {cov95*100:>6.1f}%")

metrics_df = pd.DataFrame(metrics_summary)
metrics_df.to_csv(bnn_dir / "metrics_v2_6tasks.csv", index=False)
print(f"\n   💾 metrics_v2_6tasks.csv saved")

# -----------------------------------------------------------
# Validation against 10 reference nuclei
# -----------------------------------------------------------
print("\n🎯 Validation against 10 reference nuclei")
print("-"*70)

reference_nuclei = [
    (42, 58, 100, 'Mo'),  (46, 62, 108, 'Pd'), (48, 68, 116, 'Cd'),
    (50, 66, 116, 'Sn'),  (50, 70, 120, 'Sn'), (50, 82, 132, 'Sn'),
    (52, 78, 130, 'Te'),  (54, 82, 136, 'Xe'), (58, 82, 140, 'Ce'),
    (60, 80, 140, 'Nd'),
]

print(f"{'Nucleus':<10s} ", end='')
for t in TARGET_NAMES:
    print(f"{TARGET_LABELS[t][:12]:>14s} ", end='')
print()
print("-"*120)

validation_rows = []
for Z, N, A, EL in reference_nuclei:
    row = all_preds[(all_preds['Z']==Z) & (all_preds['N']==N) & (all_preds['A']==A)]
    if len(row) == 0:
        continue
    r = row.iloc[0]
    print(f"{A}{EL:<8s} ", end='')
    val_row = {'nucleus': f'{A}{EL}', 'Z': Z, 'N': N, 'A': A}
    for t in TARGET_NAMES:
        exp  = r[f'{t}_exp']
        pred = r[f'{t}_pred']
        unc  = r[f'{t}_unc']
        if pd.isna(exp):
            print(f"{'(no exp)':>14s} ", end='')
            val_row[f'{t}_dev_sigma'] = None
        else:
            dev = abs(exp - pred) / unc if unc > 0 else 0
            print(f"{dev:>13.2f}σ ", end='')
            val_row[f'{t}_exp']  = float(exp)
            val_row[f'{t}_pred'] = float(pred)
            val_row[f'{t}_unc']  = float(unc)
            val_row[f'{t}_dev_sigma'] = float(dev)
    print()
    validation_rows.append(val_row)

validation_df = pd.DataFrame(validation_rows)
validation_df.to_csv(bnn_dir / "validation_v2_6tasks.csv", index=False)
print(f"\n   💾 validation_v2_6tasks.csv saved")

# -----------------------------------------------------------
# Coverage summary at 1σ and 2σ for the 10 reference nuclei
# -----------------------------------------------------------
print("\n📈 Coverage summary on 10 reference nuclei:")
for t in TARGET_NAMES:
    col = f'{t}_dev_sigma'
    if col in validation_df.columns:
        devs = validation_df[col].dropna().values
        if len(devs) == 0:
            continue
        cov1 = (devs <= 1.0).sum()
        cov2 = (devs <= 2.0).sum()
        print(f"   {TARGET_LABELS[t]:<25s}  1σ: {cov1}/{len(devs)} ({100*cov1/len(devs):.0f}%)  "
              f"2σ: {cov2}/{len(devs)} ({100*cov2/len(devs):.0f}%)")

# -----------------------------------------------------------
# Sn chain predictions (the heart of the paper)
# -----------------------------------------------------------
print("\n🎯 Sn isotopic chain (Z=50, even-even):")
sn_chain = all_preds[(all_preds['Z']==50) & (all_preds['N']%2==0)].sort_values('A')
sn_chain.to_csv(bnn_dir / "sn_chain_v2_6tasks.csv", index=False)
print(f"   {len(sn_chain)} isotopes saved → sn_chain_v2_6tasks.csv")

# Print preview
print(f"\n   {'A':>4s} {'Mass pred':>14s} {'E(2+) pred':>13s} {'E(4+) pred':>13s} "
      f"{'R42 pred':>10s} {'B(E2) pred':>13s}")
for _, r in sn_chain.iterrows():
    if 100 <= r['A'] <= 140 and r['A'] % 4 == 0:  # show every 4th
        print(f"   {int(r['A']):>4d} "
              f"{r['T1_mass_excess_pred']:>10.0f}±{r['T1_mass_excess_unc']:>3.0f} "
              f"{r['T3_E_2plus_pred']:>9.0f}±{r['T3_E_2plus_unc']:>3.0f} "
              f"{r['T4_E_4plus_pred']:>9.0f}±{r['T4_E_4plus_unc']:>3.0f} "
              f"{r['T5_R_42_pred']:>7.3f}±{r['T5_R_42_unc']:>.3f} "
              f"{r['T6_BE2_up_pred']:>9.4f}±{r['T6_BE2_up_unc']:>.4f}")

# -----------------------------------------------------------
# Package everything for Claude (ZIP for download)
# -----------------------------------------------------------
print("\n📦 Packaging deliverables for Claude...")

deliverables = [
    "master_v2_6targets.csv",
    "test_results_v2_6tasks.csv",
    "all_predictions_v2_6tasks.csv",
    "validation_v2_6tasks.csv",
    "sn_chain_v2_6tasks.csv",
    "metrics_v2_6tasks.csv",
    "split_v2.csv",
]

zip_path = bnn_dir / "stage7b_deliverables.zip"
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for fname in deliverables:
        fpath = bnn_dir / fname
        if fpath.exists():
            zf.write(fpath, fname)
            print(f"   ✅ Added {fname}  ({fpath.stat().st_size/1024:.1f} KB)")
        else:
            print(f"   ⚠️  Missing {fname}")

print(f"\n💾 ZIP package: {zip_path}")
print(f"   Total size: {zip_path.stat().st_size/1024:.1f} KB")

# -----------------------------------------------------------
# Summary report (the most important file for Claude)
# -----------------------------------------------------------
report_lines = [
    "="*70,
    "Stage 7B: Multi-Task BNN with 6 Outputs — TRAINING SUMMARY",
    "="*70,
    "",
    "## Architecture",
    "  - Shared trunk: 11 → 64 → 32 (deterministic, ReLU, dropout 0.1)",
    "  - 6 Bayesian heads: 32 → 16 → 1 (each)",
    "  - Prior std: 2.0",
    "  - Optimizer: Adam, lr=0.01, 2000 epochs",
    "  - Ensemble: 5 seeds (42, 123, 456, 789, 1024)",
    "  - 100 posterior samples per seed → 500 ensemble samples per nucleus",
    "",
    "## Test-Set Performance",
]
for m in metrics_summary:
    report_lines.append(
        f"  {m['label']:<25s}  "
        f"N={m['n_test']:3d}  "
        f"RMSE={m['rmse']:.4g}  "
        f"R²={m['r2']:.3f}  "
        f"ECE={m['ece']:.3f}  "
        f"Cov95={m['cov95']*100:.1f}%"
    )

report_lines += [
    "",
    "## Validation on 10 Reference Nuclei",
]
for t in TARGET_NAMES:
    col = f'{t}_dev_sigma'
    if col in validation_df.columns:
        devs = validation_df[col].dropna().values
        if len(devs) > 0:
            cov1 = (devs <= 1.0).sum()
            cov2 = (devs <= 2.0).sum()
            report_lines.append(
                f"  {TARGET_LABELS[t]:<25s}  "
                f"1σ: {cov1}/{len(devs)} ({100*cov1/len(devs):.0f}%)  "
                f"2σ: {cov2}/{len(devs)} ({100*cov2/len(devs):.0f}%)"
            )

report = "\n".join(report_lines)
with open(bnn_dir / "stage7b_summary.txt", 'w') as f:
    f.write(report)
print("\n" + report)
print("\n" + "="*70)
print("✅ STAGE 7B COMPLETE")
print("="*70)
print(f"\n📤 Send this ZIP to Claude:")
print(f"   {zip_path}")
print(f"   ({zip_path.stat().st_size/1024:.1f} KB)")
print(f"\n   Then Claude will update the paper (v4) and webapp (v2).")
