# ============================================================
# Stage 7B: COMPLETE ALL-IN-ONE Kaggle Script
# Multi-Task BNN with 6 outputs
# ============================================================
# Run this AFTER your Stage 6 notebook has produced:
#   /kaggle/working/data/master_dataset_with_BE2.csv
#   /kaggle/working/data/nudat_data_A100to150.csv
# 
# Total runtime: ~15 minutes on Tesla T4 GPU
# ============================================================

# ============================================================
# CELL 1 (Stage 7B): Build EXTENDED master dataset with 6 targets
# ============================================================
# الهدف: دمج E(4+) و R_42 من nudat_data_A100to150.csv مع master
# ثم إنشاء dataset جاهز للتدريب على 6 مخرجات
# ============================================================

import pandas as pd
import numpy as np
from pathlib import Path

output_dir = Path("/kaggle/working/data")
bnn_dir    = Path("/kaggle/working/bnn_data_v2")
bnn_dir.mkdir(parents=True, exist_ok=True)

print("="*70)
print("Stage 7B: Building 6-target master dataset")
print("="*70)

# -----------------------------------------------------------
# Load existing data
# -----------------------------------------------------------
print("\n📂 Loading existing data files...")

# Master with mass + Pritychenko B(E2) + E(2+)
master = pd.read_csv(output_dir / "master_dataset_with_BE2.csv")
print(f"   master_dataset_with_BE2.csv: {len(master)} rows × {len(master.columns)} cols")

# NUDAT-derived data (E_4plus, R_42, etc.)
nudat = pd.read_csv(output_dir / "nudat_data_A100to150.csv")
print(f"   nudat_data_A100to150.csv:    {len(nudat)} rows × {len(nudat.columns)} cols")

# -----------------------------------------------------------
# Merge E(4+) and R_42 from nudat into master
# -----------------------------------------------------------
print("\n🔗 Merging E(4+) and R_42 from NUDAT into master...")

# nudat columns to bring in
nudat_cols_to_merge = ['Z', 'A', 'E_2plus_keV', 'E_4plus_keV', 'R_42']
nudat_subset = nudat[nudat_cols_to_merge].copy()
nudat_subset = nudat_subset.rename(columns={
    'E_2plus_keV': 'E_2plus_keV_NUDAT',  # rename to avoid clash with Pritychenko
    'E_4plus_keV': 'E_4plus_keV_NUDAT',
    'R_42': 'R_42_NUDAT',
})

# Merge on (Z, A)
extended = master.merge(nudat_subset, on=['Z', 'A'], how='left')
print(f"   Extended dataset: {len(extended)} rows × {len(extended.columns)} cols")

# -----------------------------------------------------------
# Build the 6 final target columns (with clear naming)
# -----------------------------------------------------------
print("\n🎯 Building 6 target columns...")

extended['T1_mass_excess']    = extended['mass_excess_keV_value']        # 651
extended['T2_S_2n']           = extended['S_2n_value']                   # 630
extended['T3_E_2plus']        = extended['E_2plus_keV_Priti']            # 147
extended['T4_E_4plus']        = extended['E_4plus_keV_NUDAT']            # ~141
extended['T5_R_42']           = extended['R_42_NUDAT']                   # ~141
extended['T6_BE2_up']         = extended['BE2_up_e2b2_Priti']            # 134

# Coverage report
print(f"\n📊 Final 6-target coverage:")
print(f"   {'Target':<25s} {'Source':<25s} {'N':>6s} {'%':>7s}")
print("-"*70)
sources = {
    'T1_mass_excess':  'AME2020 (mass_excess)',
    'T2_S_2n':         'AME2020 (S_2n)',
    'T3_E_2plus':      'Pritychenko 2016',
    'T4_E_4plus':      'NUDAT3 (4⁺ levels)',
    'T5_R_42':         'NUDAT3 (computed)',
    'T6_BE2_up':       'Pritychenko 2016',
}
for col, src in sources.items():
    n = extended[col].notna().sum()
    pct = 100 * n / len(extended)
    print(f"   {col:<25s} {src:<25s} {n:>6d} {pct:>6.1f}%")

# -----------------------------------------------------------
# Build 11 input features (same as Stage 6)
# -----------------------------------------------------------
print(f"\n🔧 Building 11 input features...")

def magic_distance_proton(Z):
    return min(abs(Z - 50), abs(Z - 82))

def magic_distance_neutron(N):
    return min(abs(N - 50), abs(N - 82))

def valence_nucleons(Z, N):
    """Number of nucleons outside nearest closed shell"""
    p_distances = [abs(Z - m) for m in [28, 50, 82, 126]]
    n_distances = [abs(N - m) for m in [28, 50, 82, 126]]
    return min(p_distances) + min(n_distances)

extended['F01_Z']         = extended['Z']
extended['F02_N']         = extended['N']
extended['F03_A']         = extended['A']
extended['F04_dZ50']      = (extended['Z'] - 50).abs()
extended['F05_dZ82']      = (extended['Z'] - 82).abs()
extended['F06_dN50']      = (extended['N'] - 50).abs()
extended['F07_dN82']      = (extended['N'] - 82).abs()
extended['F08_Zmod2']     = extended['Z'] % 2
extended['F09_Nmod2']     = extended['N'] % 2
extended['F10_valence']   = extended.apply(lambda r: valence_nucleons(r['Z'], r['N']), axis=1)
extended['F11_eveneven']  = ((extended['Z'] % 2 == 0) & (extended['N'] % 2 == 0)).astype(int)

feature_cols = [f'F{i:02d}_' for i in range(1, 12)]
feature_cols = [c for c in extended.columns if c.startswith('F0') or c.startswith('F1')]
print(f"   Built {len(feature_cols)} features")

# -----------------------------------------------------------
# Save extended master
# -----------------------------------------------------------
target_cols  = [f'T{i}_' for i in range(1, 7)]
target_cols  = [c for c in extended.columns if c.startswith('T1_') or c.startswith('T2_')
                or c.startswith('T3_') or c.startswith('T4_') or c.startswith('T5_')
                or c.startswith('T6_')]

# Final columns: identifiers + features + targets
keep_cols = ['Z', 'N', 'A', 'EL'] + feature_cols + target_cols
extended_final = extended[keep_cols].copy()

extended_final.to_csv(bnn_dir / "master_v2_6targets.csv", index=False)
print(f"\n💾 Saved: {bnn_dir / 'master_v2_6targets.csv'}")
print(f"   Shape: {extended_final.shape}")
print(f"   Size:  {(bnn_dir / 'master_v2_6targets.csv').stat().st_size/1024:.1f} KB")

# Show first 5 rows
print(f"\n📋 First 5 rows preview:")
print(extended_final[['Z', 'N', 'A', 'EL'] + target_cols].head().to_string(index=False))

print(f"\n✅ Cell 1 complete. Move to Cell 2 (BNN training).")

# ============================================================
# CELL 2 STARTS HERE
# ============================================================
# ============================================================
# CELL 2 (Stage 7B): Train 6-Task BNN Ensemble
# ============================================================
# الهدف: تدريب 5 BNNs بـ 6 رؤوس على الـ master_v2_6targets.csv
# Architecture: Shared trunk (64→32) + 6 Bayesian heads
# ============================================================

import torch
import torch.nn as nn
import torch.nn.functional as F
import pyro
import pyro.distributions as dist
from pyro.nn import PyroModule, PyroSample
from pyro.infer import SVI, Trace_ELBO
from pyro.infer.autoguide import AutoNormal
from pyro.optim import Adam
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import time

# -----------------------------------------------------------
# Config
# -----------------------------------------------------------
output_dir = Path("/kaggle/working/data")
bnn_dir    = Path("/kaggle/working/bnn_data_v2")
models_dir = bnn_dir / "models_v2"
models_dir.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {DEVICE}")

# Hyperparameters (same as Stage 6 winning config)
HPARAMS = {
    'trunk_hidden':    [64, 32],
    'head_hidden':     16,
    'prior_std':       2.0,
    'learning_rate':   0.01,
    'epochs':          2000,
    'dropout':         0.1,
    'n_seeds':         5,
    'n_posterior':     100,  # samples per seed for prediction
}

SEEDS = [42, 123, 456, 789, 1024]

# Targets (6 tasks)
TARGET_NAMES = ['T1_mass_excess', 'T2_S_2n', 'T3_E_2plus',
                'T4_E_4plus',     'T5_R_42', 'T6_BE2_up']
TARGET_LABELS = ['Mass excess', 'S(2n)', 'E(2⁺)', 'E(4⁺)', 'R(4/2)', 'B(E2)↑']

# -----------------------------------------------------------
# Load data
# -----------------------------------------------------------
print("\n" + "="*70)
print("Stage 7B: 6-Task BNN Training")
print("="*70)

df = pd.read_csv(bnn_dir / "master_v2_6targets.csv")
print(f"\n📂 Loaded master_v2_6targets.csv: {df.shape}")

feature_cols = [c for c in df.columns if c.startswith('F0') or c.startswith('F1')]
print(f"   Features: {len(feature_cols)}")
print(f"   Targets:  {len(TARGET_NAMES)}")

X_full = df[feature_cols].values.astype(np.float32)
print(f"   X shape: {X_full.shape}")

# -----------------------------------------------------------
# Multi-Task BNN Model with 6 heads
# -----------------------------------------------------------
class MultiTaskBNN_6Tasks(PyroModule):
    """
    Shared trunk: 11 → 64 → 32 (deterministic with dropout)
    6 Bayesian heads: 32 → 16 → 1 (each)
    """
    def __init__(self, n_features=11, n_tasks=6,
                 trunk_h=[64, 32], head_h=16,
                 prior_std=2.0, dropout=0.1):
        super().__init__()
        self.n_tasks = n_tasks
        self.prior_std = prior_std
        self.dropout = dropout

        # Deterministic shared trunk
        self.trunk = nn.Sequential(
            nn.Linear(n_features, trunk_h[0]),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(trunk_h[0], trunk_h[1]),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # 6 Bayesian heads
        self.heads = PyroModule[nn.ModuleList](
            [self._make_bayesian_head(trunk_h[1], head_h, prior_std)
             for _ in range(n_tasks)]
        )

    def _make_bayesian_head(self, in_dim, hidden, prior_std):
        head = PyroModule[nn.Sequential](
            PyroModule[nn.Linear](in_dim, hidden),
            nn.ReLU(),
            PyroModule[nn.Linear](hidden, 1),
        )
        # Set Gaussian priors on all Bayesian weights
        for layer in head:
            if isinstance(layer, PyroModule[nn.Linear]):
                layer.weight = PyroSample(
                    dist.Normal(0., prior_std).expand(layer.weight.shape).to_event(2)
                )
                layer.bias = PyroSample(
                    dist.Normal(0., prior_std).expand(layer.bias.shape).to_event(1)
                )
        return head

    def forward(self, x, y_list=None, mask_list=None):
        """
        x:        (batch, n_features)
        y_list:   list of 6 tensors (each ≤ batch, with NaN where missing)
        mask_list:list of 6 boolean tensors marking valid samples per task
        """
        h = self.trunk(x)
        preds = []

        for k in range(self.n_tasks):
            pred_k = self.heads[k](h).squeeze(-1)  # (batch,)
            preds.append(pred_k)

            if y_list is not None and mask_list is not None:
                mask_k = mask_list[k]
                if mask_k.sum() > 0:
                    sigma_k = pyro.sample(
                        f"sigma_{k}",
                        dist.HalfNormal(1.0)
                    )
                    with pyro.plate(f"data_{k}", mask_k.sum()):
                        pyro.sample(
                            f"obs_{k}",
                            dist.Normal(pred_k[mask_k], sigma_k),
                            obs=y_list[k][mask_k]
                        )
        return preds


# -----------------------------------------------------------
# Per-task scalers (normalize targets in their own units)
# -----------------------------------------------------------
def fit_per_task_scaler(y_array):
    """Fit a StandardScaler per task on non-NaN values"""
    scalers = []
    for k in range(y_array.shape[1]):
        s = StandardScaler()
        valid = ~np.isnan(y_array[:, k])
        if valid.sum() > 0:
            s.fit(y_array[valid, k:k+1])
        scalers.append(s)
    return scalers

def transform_per_task(y_array, scalers):
    """Transform each task column with its scaler (NaNs preserved)"""
    out = np.full_like(y_array, np.nan, dtype=np.float32)
    for k, s in enumerate(scalers):
        valid = ~np.isnan(y_array[:, k])
        if valid.sum() > 0:
            out[valid, k] = s.transform(y_array[valid, k:k+1]).ravel()
    return out

def inverse_per_task(y_scaled, scalers):
    out = np.full_like(y_scaled, np.nan, dtype=np.float32)
    for k, s in enumerate(scalers):
        valid = ~np.isnan(y_scaled[:, k])
        if valid.sum() > 0:
            out[valid, k] = s.inverse_transform(y_scaled[valid, k:k+1]).ravel()
    return out


# -----------------------------------------------------------
# Train one BNN with given seed
# -----------------------------------------------------------
def train_one_bnn(X_tr, Y_tr, seed):
    """
    X_tr: (N, 11) features standardized
    Y_tr: (N, 6) targets standardized per-task, with NaNs for missing
    """
    pyro.set_rng_seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)
    pyro.clear_param_store()

    model = MultiTaskBNN_6Tasks(
        n_features=X_tr.shape[1], n_tasks=6,
        trunk_h=HPARAMS['trunk_hidden'],
        head_h=HPARAMS['head_hidden'],
        prior_std=HPARAMS['prior_std'],
        dropout=HPARAMS['dropout'],
    ).to(DEVICE)

    guide = AutoNormal(model)
    optimizer = Adam({"lr": HPARAMS['learning_rate']})
    svi = SVI(model, guide, optimizer, loss=Trace_ELBO())

    # Prepare per-task masks and y tensors
    X_t = torch.tensor(X_tr, dtype=torch.float32).to(DEVICE)
    y_list = []
    mask_list = []
    for k in range(6):
        y_col = Y_tr[:, k]
        mask = torch.tensor(~np.isnan(y_col), dtype=torch.bool).to(DEVICE)
        y_t = torch.tensor(np.nan_to_num(y_col), dtype=torch.float32).to(DEVICE)
        y_list.append(y_t)
        mask_list.append(mask)

    losses = []
    for epoch in range(HPARAMS['epochs']):
        loss = svi.step(X_t, y_list, mask_list)
        losses.append(loss)
        if (epoch+1) % 200 == 0:
            print(f"      [seed {seed}] Epoch {epoch+1:>4d}/{HPARAMS['epochs']}  ELBO loss = {loss:.1f}")

    return model, guide, losses


# -----------------------------------------------------------
# Posterior prediction
# -----------------------------------------------------------
def predict_posterior(model, guide, X, n_samples=100):
    """Returns (n_samples, N, 6) predictions in scaled space"""
    X_t = torch.tensor(X, dtype=torch.float32).to(DEVICE)
    samples = []
    for _ in range(n_samples):
        guide_trace = pyro.poutine.trace(guide).get_trace(X_t)
        replayed = pyro.poutine.replay(model, trace=guide_trace)
        with torch.no_grad():
            preds = replayed(X_t)
        sample = torch.stack(preds, dim=-1).cpu().numpy()  # (N, 6)
        samples.append(sample)
    return np.array(samples)  # (n_samples, N, 6)


# -----------------------------------------------------------
# 70/15/15 split (deterministic — same seed for all BNNs)
# -----------------------------------------------------------
print("\n📐 Splitting data 70/15/15...")
N = len(df)
indices = np.arange(N)
np.random.seed(42)
np.random.shuffle(indices)
n_tr = int(0.70 * N)
n_va = int(0.15 * N)
idx_tr = indices[:n_tr]
idx_va = indices[n_tr:n_tr+n_va]
idx_te = indices[n_tr+n_va:]
print(f"   Train: {len(idx_tr)},  Val: {len(idx_va)},  Test: {len(idx_te)}")

X_tr = X_full[idx_tr]
X_va = X_full[idx_va]
X_te = X_full[idx_te]

Y_full = df[TARGET_NAMES].values.astype(np.float32)
Y_tr = Y_full[idx_tr]
Y_va = Y_full[idx_va]
Y_te = Y_full[idx_te]

# Standardize features
x_scaler = StandardScaler().fit(X_tr)
X_tr_s = x_scaler.transform(X_tr).astype(np.float32)
X_va_s = x_scaler.transform(X_va).astype(np.float32)
X_te_s = x_scaler.transform(X_te).astype(np.float32)

# Standardize targets per-task
y_scalers = fit_per_task_scaler(Y_tr)
Y_tr_s   = transform_per_task(Y_tr, y_scalers)
Y_va_s   = transform_per_task(Y_va, y_scalers)
Y_te_s   = transform_per_task(Y_te, y_scalers)

# -----------------------------------------------------------
# Train ensemble of 5 BNNs
# -----------------------------------------------------------
print(f"\n🧠 Training ensemble of {HPARAMS['n_seeds']} BNNs...")
print(f"   Each: {HPARAMS['epochs']} epochs, ~100s on T4")

ensemble_preds_te_scaled = []   # list of (n_samples, N_test, 6)
ensemble_preds_full_scaled = [] # list of (n_samples, 651, 6) for ALL nuclei

start = time.time()
for seed_idx, seed in enumerate(SEEDS):
    print(f"\n   [{seed_idx+1}/{HPARAMS['n_seeds']}] Training seed={seed}...")
    t0 = time.time()
    model, guide, losses = train_one_bnn(X_tr_s, Y_tr_s, seed)
    elapsed = time.time() - t0
    print(f"      ✅ Trained in {elapsed:.1f}s")

    # Save model state
    pyro.get_param_store().save(str(models_dir / f"bnn_v2_seed{seed}.pt"))

    # Predictions on test set
    preds_te = predict_posterior(model, guide, X_te_s, HPARAMS['n_posterior'])
    ensemble_preds_te_scaled.append(preds_te)

    # Predictions on FULL dataset (for download/use)
    X_full_s = x_scaler.transform(X_full).astype(np.float32)
    preds_full = predict_posterior(model, guide, X_full_s, HPARAMS['n_posterior'])
    ensemble_preds_full_scaled.append(preds_full)

total_time = time.time() - start
print(f"\n   ⏱️ Total ensemble training time: {total_time/60:.1f} minutes")

# -----------------------------------------------------------
# Combine ensemble predictions
# -----------------------------------------------------------
print(f"\n🎯 Combining ensemble predictions...")

# Test set
all_preds_te = np.concatenate(ensemble_preds_te_scaled, axis=0)  # (5*100, N_test, 6)
mean_te_scaled = all_preds_te.mean(axis=0)
std_te_scaled  = all_preds_te.std(axis=0)
mean_te = inverse_per_task(mean_te_scaled, y_scalers)
# Inverse for std: multiply by per-task std (since standardization is linear)
std_te = std_te_scaled.copy()
for k, s in enumerate(y_scalers):
    if hasattr(s, 'scale_'):
        std_te[:, k] = std_te_scaled[:, k] * s.scale_[0]

# Full dataset
all_preds_full = np.concatenate(ensemble_preds_full_scaled, axis=0)
mean_full_scaled = all_preds_full.mean(axis=0)
std_full_scaled  = all_preds_full.std(axis=0)
mean_full = inverse_per_task(mean_full_scaled, y_scalers)
std_full = std_full_scaled.copy()
for k, s in enumerate(y_scalers):
    if hasattr(s, 'scale_'):
        std_full[:, k] = std_full_scaled[:, k] * s.scale_[0]

# -----------------------------------------------------------
# Save predictions
# -----------------------------------------------------------
print(f"\n💾 Saving predictions...")

# Test set with metrics
test_results = pd.DataFrame({
    'Z': df.iloc[idx_te]['Z'].values,
    'N': df.iloc[idx_te]['N'].values,
    'A': df.iloc[idx_te]['A'].values,
    'EL': df.iloc[idx_te]['EL'].values,
})
for k, t in enumerate(TARGET_NAMES):
    test_results[f'{t}_exp']  = Y_te[:, k]
    test_results[f'{t}_pred'] = mean_te[:, k]
    test_results[f'{t}_unc']  = std_te[:, k]
test_results.to_csv(bnn_dir / "test_results_v2_6tasks.csv", index=False)
print(f"   ✅ test_results_v2_6tasks.csv  ({(bnn_dir / 'test_results_v2_6tasks.csv').stat().st_size/1024:.1f} KB)")

# Full predictions for all 651 nuclei
all_predictions = df[['Z', 'N', 'A', 'EL']].copy()
for k, t in enumerate(TARGET_NAMES):
    all_predictions[f'{t}_exp']  = Y_full[:, k]
    all_predictions[f'{t}_pred'] = mean_full[:, k]
    all_predictions[f'{t}_unc']  = std_full[:, k]
all_predictions.to_csv(bnn_dir / "all_predictions_v2_6tasks.csv", index=False)
print(f"   ✅ all_predictions_v2_6tasks.csv  ({(bnn_dir / 'all_predictions_v2_6tasks.csv').stat().st_size/1024:.1f} KB)")

# Save split indices for reproducibility
split_info = pd.DataFrame({
    'index': np.concatenate([idx_tr, idx_va, idx_te]),
    'split': ['train']*len(idx_tr) + ['val']*len(idx_va) + ['test']*len(idx_te)
})
split_info.to_csv(bnn_dir / "split_v2.csv", index=False)
print(f"   ✅ split_v2.csv")

print(f"\n✅ Cell 2 complete. Move to Cell 3 (evaluation & metrics).")

# ============================================================
# CELL 3 STARTS HERE
# ============================================================
# ============================================================
# CELL 3 (Stage 7B): Metrics, Calibration, and Final Deliverables
# ============================================================
# الهدف: حساب RMSE, R², ECE, coverage لكل المخرجات الـ 6
# ثم packaging كل الملفات لإرسالها لـ Claude
# ============================================================

import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.metrics import r2_score, mean_squared_error
import zipfile

bnn_dir = Path("/kaggle/working/bnn_data_v2")

print("="*70)
print("Stage 7B: Metrics + Calibration + Packaging")
print("="*70)

# -----------------------------------------------------------
# Load predictions
# -----------------------------------------------------------
test_results = pd.read_csv(bnn_dir / "test_results_v2_6tasks.csv")
all_preds    = pd.read_csv(bnn_dir / "all_predictions_v2_6tasks.csv")

TARGET_NAMES = ['T1_mass_excess', 'T2_S_2n', 'T3_E_2plus',
                'T4_E_4plus',     'T5_R_42', 'T6_BE2_up']
TARGET_LABELS = {
    'T1_mass_excess': 'Mass excess (keV)',
    'T2_S_2n':        'S(2n) (keV)',
    'T3_E_2plus':     'E(2⁺) (keV)',
    'T4_E_4plus':     'E(4⁺) (keV)',
    'T5_R_42':        'R(4/2) ratio',
    'T6_BE2_up':      'B(E2)↑ (e²b²)',
}

# -----------------------------------------------------------
# Test-set performance metrics
# -----------------------------------------------------------
print("\n📊 Test-set performance metrics")
print("-"*70)
print(f"{'Task':<25s} {'N':>4s} {'RMSE':>12s} {'R²':>7s} {'ECE':>7s} {'Cov68':>7s} {'Cov95':>7s}")
print("-"*70)

metrics_summary = []
for t in TARGET_NAMES:
    exp = test_results[f'{t}_exp'].values
    pred = test_results[f'{t}_pred'].values
    unc  = test_results[f'{t}_unc'].values
    valid = ~np.isnan(exp)

    n = valid.sum()
    if n < 2:
        metrics_summary.append({
            'task': t, 'label': TARGET_LABELS[t], 'n_test': n,
            'rmse': np.nan, 'r2': np.nan, 'ece': np.nan,
            'cov68': np.nan, 'cov95': np.nan
        })
        continue

    e = exp[valid]; p = pred[valid]; u = unc[valid]
    rmse = np.sqrt(np.mean((e - p)**2))
    r2 = r2_score(e, p)

    # Coverage at multiple alpha levels for ECE
    alphas = np.linspace(0.05, 0.99, 20)
    coverages = []
    from scipy.stats import norm
    for a in alphas:
        z = norm.ppf((1 + a) / 2)  # two-sided
        cov = np.mean(np.abs(e - p) <= z * u)
        coverages.append(cov)
    coverages = np.array(coverages)
    ece = np.mean(np.abs(coverages - alphas))

    # Specific 68% and 95% coverage
    cov68 = np.mean(np.abs(e - p) <= 1.0 * u)
    cov95 = np.mean(np.abs(e - p) <= 1.96 * u)

    metrics_summary.append({
        'task': t, 'label': TARGET_LABELS[t], 'n_test': int(n),
        'rmse': float(rmse), 'r2': float(r2), 'ece': float(ece),
        'cov68': float(cov68), 'cov95': float(cov95)
    })

    print(f"{TARGET_LABELS[t]:<25s} {n:>4d} {rmse:>12.4g} {r2:>7.3f} "
          f"{ece:>7.3f} {cov68*100:>6.1f}% {cov95*100:>6.1f}%")

metrics_df = pd.DataFrame(metrics_summary)
metrics_df.to_csv(bnn_dir / "metrics_v2_6tasks.csv", index=False)
print(f"\n   💾 metrics_v2_6tasks.csv saved")

# -----------------------------------------------------------
# Validation against 10 reference nuclei
# -----------------------------------------------------------
print("\n🎯 Validation against 10 reference nuclei")
print("-"*70)

reference_nuclei = [
    (42, 58, 100, 'Mo'),  (46, 62, 108, 'Pd'), (48, 68, 116, 'Cd'),
    (50, 66, 116, 'Sn'),  (50, 70, 120, 'Sn'), (50, 82, 132, 'Sn'),
    (52, 78, 130, 'Te'),  (54, 82, 136, 'Xe'), (58, 82, 140, 'Ce'),
    (60, 80, 140, 'Nd'),
]

print(f"{'Nucleus':<10s} ", end='')
for t in TARGET_NAMES:
    print(f"{TARGET_LABELS[t][:12]:>14s} ", end='')
print()
print("-"*120)

validation_rows = []
for Z, N, A, EL in reference_nuclei:
    row = all_preds[(all_preds['Z']==Z) & (all_preds['N']==N) & (all_preds['A']==A)]
    if len(row) == 0:
        continue
    r = row.iloc[0]
    print(f"{A}{EL:<8s} ", end='')
    val_row = {'nucleus': f'{A}{EL}', 'Z': Z, 'N': N, 'A': A}
    for t in TARGET_NAMES:
        exp  = r[f'{t}_exp']
        pred = r[f'{t}_pred']
        unc  = r[f'{t}_unc']
        if pd.isna(exp):
            print(f"{'(no exp)':>14s} ", end='')
            val_row[f'{t}_dev_sigma'] = None
        else:
            dev = abs(exp - pred) / unc if unc > 0 else 0
            print(f"{dev:>13.2f}σ ", end='')
            val_row[f'{t}_exp']  = float(exp)
            val_row[f'{t}_pred'] = float(pred)
            val_row[f'{t}_unc']  = float(unc)
            val_row[f'{t}_dev_sigma'] = float(dev)
    print()
    validation_rows.append(val_row)

validation_df = pd.DataFrame(validation_rows)
validation_df.to_csv(bnn_dir / "validation_v2_6tasks.csv", index=False)
print(f"\n   💾 validation_v2_6tasks.csv saved")

# -----------------------------------------------------------
# Coverage summary at 1σ and 2σ for the 10 reference nuclei
# -----------------------------------------------------------
print("\n📈 Coverage summary on 10 reference nuclei:")
for t in TARGET_NAMES:
    col = f'{t}_dev_sigma'
    if col in validation_df.columns:
        devs = validation_df[col].dropna().values
        if len(devs) == 0:
            continue
        cov1 = (devs <= 1.0).sum()
        cov2 = (devs <= 2.0).sum()
        print(f"   {TARGET_LABELS[t]:<25s}  1σ: {cov1}/{len(devs)} ({100*cov1/len(devs):.0f}%)  "
              f"2σ: {cov2}/{len(devs)} ({100*cov2/len(devs):.0f}%)")

# -----------------------------------------------------------
# Sn chain predictions (the heart of the paper)
# -----------------------------------------------------------
print("\n🎯 Sn isotopic chain (Z=50, even-even):")
sn_chain = all_preds[(all_preds['Z']==50) & (all_preds['N']%2==0)].sort_values('A')
sn_chain.to_csv(bnn_dir / "sn_chain_v2_6tasks.csv", index=False)
print(f"   {len(sn_chain)} isotopes saved → sn_chain_v2_6tasks.csv")

# Print preview
print(f"\n   {'A':>4s} {'Mass pred':>14s} {'E(2+) pred':>13s} {'E(4+) pred':>13s} "
      f"{'R42 pred':>10s} {'B(E2) pred':>13s}")
for _, r in sn_chain.iterrows():
    if 100 <= r['A'] <= 140 and r['A'] % 4 == 0:  # show every 4th
        print(f"   {int(r['A']):>4d} "
              f"{r['T1_mass_excess_pred']:>10.0f}±{r['T1_mass_excess_unc']:>3.0f} "
              f"{r['T3_E_2plus_pred']:>9.0f}±{r['T3_E_2plus_unc']:>3.0f} "
              f"{r['T4_E_4plus_pred']:>9.0f}±{r['T4_E_4plus_unc']:>3.0f} "
              f"{r['T5_R_42_pred']:>7.3f}±{r['T5_R_42_unc']:>.3f} "
              f"{r['T6_BE2_up_pred']:>9.4f}±{r['T6_BE2_up_unc']:>.4f}")

# -----------------------------------------------------------
# Package everything for Claude (ZIP for download)
# -----------------------------------------------------------
print("\n📦 Packaging deliverables for Claude...")

deliverables = [
    "master_v2_6targets.csv",
    "test_results_v2_6tasks.csv",
    "all_predictions_v2_6tasks.csv",
    "validation_v2_6tasks.csv",
    "sn_chain_v2_6tasks.csv",
    "metrics_v2_6tasks.csv",
    "split_v2.csv",
]

zip_path = bnn_dir / "stage7b_deliverables.zip"
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for fname in deliverables:
        fpath = bnn_dir / fname
        if fpath.exists():
            zf.write(fpath, fname)
            print(f"   ✅ Added {fname}  ({fpath.stat().st_size/1024:.1f} KB)")
        else:
            print(f"   ⚠️  Missing {fname}")

print(f"\n💾 ZIP package: {zip_path}")
print(f"   Total size: {zip_path.stat().st_size/1024:.1f} KB")

# -----------------------------------------------------------
# Summary report (the most important file for Claude)
# -----------------------------------------------------------
report_lines = [
    "="*70,
    "Stage 7B: Multi-Task BNN with 6 Outputs — TRAINING SUMMARY",
    "="*70,
    "",
    "## Architecture",
    "  - Shared trunk: 11 → 64 → 32 (deterministic, ReLU, dropout 0.1)",
    "  - 6 Bayesian heads: 32 → 16 → 1 (each)",
    "  - Prior std: 2.0",
    "  - Optimizer: Adam, lr=0.01, 2000 epochs",
    "  - Ensemble: 5 seeds (42, 123, 456, 789, 1024)",
    "  - 100 posterior samples per seed → 500 ensemble samples per nucleus",
    "",
    "## Test-Set Performance",
]
for m in metrics_summary:
    report_lines.append(
        f"  {m['label']:<25s}  "
        f"N={m['n_test']:3d}  "
        f"RMSE={m['rmse']:.4g}  "
        f"R²={m['r2']:.3f}  "
        f"ECE={m['ece']:.3f}  "
        f"Cov95={m['cov95']*100:.1f}%"
    )

report_lines += [
    "",
    "## Validation on 10 Reference Nuclei",
]
for t in TARGET_NAMES:
    col = f'{t}_dev_sigma'
    if col in validation_df.columns:
        devs = validation_df[col].dropna().values
        if len(devs) > 0:
            cov1 = (devs <= 1.0).sum()
            cov2 = (devs <= 2.0).sum()
            report_lines.append(
                f"  {TARGET_LABELS[t]:<25s}  "
                f"1σ: {cov1}/{len(devs)} ({100*cov1/len(devs):.0f}%)  "
                f"2σ: {cov2}/{len(devs)} ({100*cov2/len(devs):.0f}%)"
            )

report = "\n".join(report_lines)
with open(bnn_dir / "stage7b_summary.txt", 'w') as f:
    f.write(report)
print("\n" + report)
print("\n" + "="*70)
print("✅ STAGE 7B COMPLETE")
print("="*70)
print(f"\n📤 Send this ZIP to Claude:")
print(f"   {zip_path}")
print(f"   ({zip_path.stat().st_size/1024:.1f} KB)")
print(f"\n   Then Claude will update the paper (v4) and webapp (v2).")
