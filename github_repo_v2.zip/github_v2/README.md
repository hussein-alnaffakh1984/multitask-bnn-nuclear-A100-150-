# Multi-Task Bayesian Neural Network for Nuclear Structure (A = 100–150)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.10-orange.svg)](https://pytorch.org/)
[![Pyro](https://img.shields.io/badge/Pyro-1.9-blueviolet.svg)](https://pyro.ai/)

A multi-task Bayesian neural network ensemble that jointly predicts **six nuclear observables** with calibrated uncertainty estimates for 651 nuclei in the medium-mass region (40 ≤ Z ≤ 60, 50 ≤ N ≤ 90).

---

## 🎯 What it does

Given a proton number Z and neutron number N, the model returns predictions with calibrated 1σ uncertainties for:

| # | Observable | Unit | Source | Test R² |
|:--|:---|:---:|:---|:---:|
| 1 | **Mass excess** | keV | AME2020 | **0.993** |
| 2 | **S(2n)** | keV | AME2020 | **0.985** |
| 3 | **E(2⁺)** | keV | Pritychenko 2016 | 0.496 |
| 4 | **E(4⁺)** | keV | NUDAT3 | 0.689 |
| 5 | **R(4/2)** ratio | — | computed | 0.630 |
| 6 | **B(E2; 0⁺→2⁺)** | e²b² | Pritychenko 2016 | **0.920** |

---

## 🚀 Quick start

### Option 1 — Use the interactive web app
Visit the deployed app at **[Project Netlify URL]** to query predictions for any nucleus in the studied region.

### Option 2 — Reproduce the training
```bash
# Clone the repo
git clone https://github.com/hussein-alnaffakh1984/multitask-bnn-nuclear-A100-150
cd multitask-bnn-nuclear-A100-150

# Install dependencies
pip install -r requirements.txt

# Run the full pipeline (Kaggle Tesla T4 recommended; ~20 minutes)
python scripts/stage7b_all_in_one.py
```

### Option 3 — Use pre-computed predictions
Open `results/all_predictions_v2_6tasks.csv` to get all 651 nuclear predictions directly.

---

## 📊 Key results

### Architecture
- **Shared trunk**: 11 features → 64 → 32 (ReLU, dropout 0.1, deterministic)
- **6 Bayesian heads**: 32 → 16 → 1 (mean-field variational, Pyro 1.9)
- **Ensemble**: 5 BNNs × 100 posterior samples = **500 ensemble samples per nucleus**

### Multi-task gain (ablation)
Multi-task learning improves E(2⁺) prediction by **+29% in R²** vs. single-task BNN, demonstrating that shared representations transfer information across correlated nuclear observables.

| Task | Single-task | Multi-task + Ensemble | Gain |
|:---|:---:|:---:|:---:|
| Mass excess | R² = 0.992 | **R² = 0.993** | +0.1% |
| S(2n) | R² = 0.981 | **R² = 0.985** | +0.4% |
| E(2⁺) | R² = 0.384 | **R² = 0.496** | **+29%** |
| E(4⁺) | R² = 0.621 | **R² = 0.689** | +11% |
| R(4/2) | R² = 0.546 | **R² = 0.630** | +15% |
| B(E2) | R² = 0.908 | **R² = 0.920** | +1.3% |

### Validation on 10 reference nuclei
**100% coverage at 2σ** for mass excess, S(2n), E(2⁺), E(4⁺), and B(E2). The famous ¹³²Sn doubly-magic outlier is correctly flagged with widened uncertainty (within 0.7σ when σ is honored).

### B(E2) anomaly in tin
The model reproduces the celebrated ¹¹⁶Sn B(E2) plateau within 1σ of the experimental value, despite using only 11 simple physics-motivated features (no shell-model input).

---

## 📁 Repository structure

```
multitask-bnn-nuclear-A100-150/
├── data/                                    # Raw + processed datasets
│   ├── ame2020_master_A100to150.csv        # AME2020 mass evaluation
│   ├── pritychenko_2016_A100to150_FIXED.csv # B(E2) compilation
│   ├── master_dataset_with_BE2.csv          # Joined master (3 targets)
│   └── master_v2_6targets.csv               # Final 6-target training set
│
├── results/                                 # Trained model predictions
│   ├── all_predictions_v2_6tasks.csv        # Predictions for all 651 nuclei
│   ├── test_results_v2_6tasks.csv           # Held-out test set
│   ├── validation_v2_6tasks.csv             # 10 reference nuclei
│   ├── sn_chain_v2_6tasks.csv               # Tin chain predictions
│   ├── metrics_v2_6tasks.csv                # Performance summary
│   └── split_v2.csv                         # Train/val/test indices
│
├── figures/                                 # Publication-quality figures
│   ├── fig01.png  # Nuclei distribution
│   ├── fig02.png  # Sn anomaly motivation
│   ├── fig03.png  # Predicted vs experimental (test set)
│   ├── fig04.png  # Sn chain BNN predictions
│   ├── fig05.png  # Uncertainty heatmap
│   └── fig06.png  # Calibration curves
│
├── paper/
│   └── Multi-Task-BNN-Nuclear-A100-150-v4.docx  # Manuscript
│
├── scripts/                                 # Training pipeline
│   ├── 01_build_dataset.py                  # Merge data sources
│   ├── 02_train_bnn.py                      # Train 5-BNN ensemble
│   ├── 03_metrics.py                        # Compute metrics
│   └── stage7b_all_in_one.py                # Full pipeline (one file)
│
├── webapp/                                  # Netlify-ready web app
│   ├── index.html
│   ├── css/style.css
│   ├── js/app.js
│   ├── js/data.js
│   └── nuclei_data.json                     # 651 predictions
│
├── README.md
├── LICENSE                                  # MIT
└── requirements.txt
```

---

## 🔬 Methodology

### Bayesian framework
The network weights w are random variables with prior p(w). Variational inference approximates the posterior p(w|D) by a mean-field Gaussian guide q_φ(w):

$$q_\phi(w) = \prod_i \mathcal{N}(w_i \mid \mu_i, \sigma_i^2)$$

Optimization minimizes the negative ELBO:

$$\mathcal{L}(\phi) = -\mathbb{E}_{q_\phi}[\log p(D|w)] + \mathrm{KL}(q_\phi(w) \| p(w))$$

### Cross-task masking
Each task contributes to the loss only for nuclei with experimentally measured target values. This allows the larger mass-excess sample (651 nuclei) to regularize the shared trunk for tasks with smaller samples (134 B(E2) nuclei) without imputation.

### Ensemble averaging
500 ensemble samples per nucleus (5 seeds × 100 posterior samples) yield the predictive mean and standard deviation:

$$\mu(x) = \frac{1}{500}\sum_{k,j} f_{k,j}(x), \quad \sigma^2(x) = \frac{1}{500}\sum_{k,j} (f_{k,j}(x) - \mu(x))^2$$

---

## 📚 Data sources

1. **AME2020** — M. Wang et al., Chinese Phys. C **45**, 030003 (2021)
2. **Pritychenko 2016** — B. Pritychenko et al., At. Data Nucl. Data Tables **107**, 1 (2016)
3. **NUDAT3** — National Nuclear Data Center, Brookhaven National Laboratory

---

## 📑 Citation

If you use this code or data, please cite:

```bibtex
@article{Alnaffakh2026MTBNN,
  title   = {Multi-Task Bayesian Neural Network Ensemble for Joint Prediction
             of Nuclear Mass, Separation Energies, and Quadrupole Collectivity
             in Medium-Mass Nuclei},
  author  = {M. M. Hussein Ali Hussein Al-Naffakh},
  journal = {[Manuscript in preparation]},
  year    = {2026},
  note    = {Code: https://github.com/hussein-alnaffakh1984/multitask-bnn-nuclear-A100-150}
}
```

---

## 👤 Author

**M. M. Hussein Ali Hussein Al-Naffakh**
Department of Physics, Faculty of Science
Al-Kafeel University, Najaf 54001, Iraq

GitHub: [@hussein-alnaffakh1984](https://github.com/hussein-alnaffakh1984)

---

## 📜 License

This project is released under the **MIT License**. See `LICENSE` for details.

---

## 🤝 Contributing

Bug reports and pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

---

## 🙏 Acknowledgments

- **Kaggle** for free Tesla T4 GPU access
- **PyTorch** and **Pyro** development teams
- **NNDC at Brookhaven** for maintaining open nuclear data
- The **AME2020** and **Pritychenko 2016** evaluation teams
